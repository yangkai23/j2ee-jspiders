/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.ArrayList;

/**
 *
 * @author ranganath
 */
public class WordCluster {
   
    ArrayList<ClusterDomain> cluster=new ArrayList<ClusterDomain>();
}
